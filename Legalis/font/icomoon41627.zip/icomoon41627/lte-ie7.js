/* Load this script using conditional IE comments if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
			'icon-ajuda' : '&#xe000;',
			'icon-alarme' : '&#xe001;',
			'icon-anexo' : '&#xe002;',
			'icon-calendar' : '&#xe003;',
			'icon-checado' : '&#xe004;',
			'icon-comentatexto' : '&#xe005;',
			'icon-comentavazio' : '&#xe006;',
			'icon-compartilhar' : '&#xe007;',
			'icon-config' : '&#xe008;',
			'icon-dash1' : '&#xe009;',
			'icon-dinheiro' : '&#xe00a;',
			'icon-documentcheio' : '&#xe00b;',
			'icon-documentovazio' : '&#xe00c;',
			'icon-editar' : '&#xe00d;',
			'icon-email' : '&#xe00e;',
			'icon-errado' : '&#xe00f;',
			'icon-escritorio' : '&#xe010;',
			'icon-estrela' : '&#xe011;',
			'icon-homem' : '&#xe012;',
			'icon-info' : '&#xe013;',
			'icon-legalis' : '&#xe014;',
			'icon-map' : '&#xe015;',
			'icon-menu1' : '&#xe016;',
			'icon-menu2' : '&#xe017;',
			'icon-mulher' : '&#xe018;',
			'icon-notificacao' : '&#xe019;',
			'icon-pasta' : '&#xe01a;',
			'icon-pessoas' : '&#xe01b;',
			'icon-processo' : '&#xe01c;',
			'icon-proibido' : '&#xe01d;',
			'icon-publicacoes' : '&#xe01e;',
			'icon-salvar' : '&#xe01f;',
			'icon-salvo' : '&#xe020;',
			'icon-setabaixo' : '&#xe021;',
			'icon-setabaixocima' : '&#xe022;',
			'icon-setacima' : '&#xe023;',
			'icon-telefone' : '&#xe024;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
};